package org.lcl.dispatchtool.request;

public class DispatchSearchRequest {

	private String[] owningLocations;
	
	private String[] altLocations;
	
	private String[] status;
	
	private String[] zone;
	
	private String startDate;
	
	private String endDate;
	
	private String locationId;
	
	private String carrierId;
	
	private String route;

	public String[] getOwningLocations() {
		return owningLocations;
	}

	public void setOwningLocations(String[] owningLocations) {
		this.owningLocations = owningLocations;
	}

	public String[] getAltLocations() {
		return altLocations;
	}

	public void setAltLocations(String[] altLocations) {
		this.altLocations = altLocations;
	}

	public String[] getStatus() {
		return status;
	}

	public void setStatus(String[] status) {
		this.status = status;
	}

	public String[] getZone() {
		return zone;
	}

	public void setZone(String[] zone) {
		this.zone = zone;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public String getCarrierId() {
		return carrierId;
	}

	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}

}
