package org.lcl.dispatchtool.jdbc.query;

import org.springframework.util.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lcl.dispatchtool.request.DispatchSearchRequest;
import org.lcl.dispatchtool.util.AppConstants;
import org.lcl.dispatchtool.util.ObjectCheckUtil;

public class DispatchDataQueryBuilder {
	
    private static final Logger LOGGER = LogManager.getLogger(DispatchDataQueryBuilder.class);
	public static final int RESULT_DATA_LIMIT = AppConstants.RESULT_DATA_LIMIT;

	public static String getOwningLocations(String[] userOwningLocations) {
		StringBuffer queryString = new StringBuffer();
		StringBuilder codes = new StringBuilder(); 

		if (!ObjectCheckUtil.isArrayEmpty(userOwningLocations)) {
			for (String code : userOwningLocations) {
				codes.append("'").append(code).append("',");
			}
			codes = codes.deleteCharAt(codes.length() - 1);
		} else {
			codes.append("''");
		}
		//SELECT DISTINCT SHPG_LOC_CD, SHPG_LOC_CD||' - '||NAME FROM SHPG_LOC_T WHERE EXTL_CD2 IN ('DC-05', 'DC-06') 
		//AND SHPG_LOC_CD IN ('p_user_owning_loc') ORDER BY SHPG_LOC_CD;
		queryString
				.append("SELECT DISTINCT SHPG_LOC_CD, SHPG_LOC_CD||' - '||NAME AS NAME FROM SHPG_LOC_T ")
				.append(" WHERE EXTL_CD2 IN ( 'DC-05', 'DC-06' )")
				.append(" AND SHPG_LOC_CD IN (").append(codes.toString())
				.append(") ORDER BY SHPG_LOC_CD");

		return queryString.toString();
	}

	public static String getAltLocations(String[] extl_cd2) {
		StringBuffer queryString = new StringBuffer();
		//SELECT DISTINCT SHPG_LOC_CD, SHPG_LOC_CD||' - '||NAME FROM SHPG_LOC_T 
		//WHERE EXTL_CD2 IN ('INTERCHANGE-98') ORDER BY SHPG_LOC_CD
		queryString
				.append("SELECT DISTINCT SHPG_LOC_CD, SHPG_LOC_CD||' - '||NAME AS NAME FROM SHPG_LOC_T ")
				.append(" WHERE EXTL_CD2 IN ('INTERCHANGE-98')")
				.append(" ORDER BY SHPG_LOC_CD ");

		return queryString.toString();
	}

	public static String getDispatchStatuses(String ln) {
		StringBuffer queryString = new StringBuffer();

		//SELECT CODE, ENGLISHDESCRIPTION, FRENCHDESCRIPTION FROM TLD_LOOKUPCODE WHERE CODECATEGORY = 'DPTSTATUS' ORDER BY CODEORDER;
		queryString
				.append("SELECT CODE, ");
			if (null == ln || ln.equalsIgnoreCase("en")) {
				queryString.append("ENGLISHDESCRIPTION AS DESCRIPTION");
			} else {
				queryString.append("FRENCHDESCRIPTION AS DESCRIPTION");
			}
		queryString.append(" FROM TLD_LOOKUPCODE WHERE CODECATEGORY = 'DPTSTATUS' ORDER BY CODEORDER ");

		return queryString.toString();
	}

	public static String getDispatchRoutes(String query) {
		StringBuffer queryString = new StringBuffer();

		//SELECT LD_LEG_ID FROM LD_LEG_T WHERE LD_LEG_ID LIKE '%101%';
		if (!StringUtils.hasLength(query)) {
			queryString.append("SELECT LD_LEG_ID FROM LD_LEG_T WHERE ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY LD_LEG_ID");
			return queryString.toString();
		} else {
			queryString.append("SELECT LD_LEG_ID FROM LD_LEG_T WHERE LD_LEG_ID LIKE ?")
				.append(" AND ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY LD_LEG_ID");
			return queryString.toString();
		}
	}

	public static String getDispatchCarrierIds(String query) {
		StringBuffer queryString = new StringBuffer();

		//SELECT CARR_CD, CARR_CD||' - '||NAME AS CARR_NAME FROM CARR_T ORDER BY CARR_CD
		if (!StringUtils.hasLength(query)) {
			queryString.append("SELECT CARR_CD, CARR_CD||' - '||NAME AS CARR_NAME FROM CARR_T WHERE ROWNUM <= ")
				.append(RESULT_DATA_LIMIT).append(" ORDER BY CARR_CD");
			return queryString.toString();
		} else {
			queryString.append("SELECT CARR_CD, CARR_CD||' - '||NAME AS CARR_NAME FROM CARR_T WHERE NAME LIKE ?")
				.append(" AND ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY CARR_CD");
			return queryString.toString();
		}
	}

	public static String getDispatchLocationIds(String query) {
		StringBuffer queryString = new StringBuffer();

		//SELECT DISTINCT SHPG_LOC_CD, SHPG_LOC_CD||' - '||NAME FROM SHPG_LOC_T WHERE NAME LIKE '%TAS%' ORDER BY SHPG_LOC_CD;
		if (!StringUtils.hasLength(query)) {
			queryString.append("SELECT DISTINCT SHPG_LOC_CD FROM SHPG_LOC_T WHERE ")
				.append("ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY SHPG_LOC_CD");
			return queryString.toString();
		} else {
			queryString.append("SELECT DISTINCT SHPG_LOC_CD FROM SHPG_LOC_T WHERE UPPER(SHPG_LOC_CD) LIKE ?")
				.append(" AND ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY SHPG_LOC_CD");
			return queryString.toString();
		}
	}

	public static String getDispatchZones(String query) {
		StringBuffer queryString = new StringBuffer();

		//SELECT DISTINCT CORP2_ID FROM SHPG_LOC_T WHERE CORP2_ID LIKE 'ON%';
			if (!StringUtils.hasLength(query)) {
				queryString.append("SELECT DISTINCT CORP2_ID FROM SHPG_LOC_T WHERE ")
					.append("ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY CORP2_ID");
				return queryString.toString();
			} else {
				queryString.append("SELECT DISTINCT CORP2_ID FROM SHPG_LOC_T WHERE UPPER(CORP2_ID) LIKE ?")
					.append(" AND ROWNUM <= ").append(RESULT_DATA_LIMIT).append(" ORDER BY CORP2_ID");
				return queryString.toString();
			}
	}

	public static String getSearchDataQuery(DispatchSearchRequest dispatchSearchReq) {
		StringBuffer searchString = new StringBuffer();
		LOGGER.info("START -- DispatchDataQueryBuilder -- getSearchDataQuery -- "+dispatchSearchReq.getStartDate());
		searchString.append("SELECT distinct U.MV_ID, U.TRIP_ID, U.SEQ_NUM, U.LOAD_ID AS LOAD_ID, U.START_DATE AS START_DATE, \r\n")
			.append("U.CARRIER_ID AS CARRIER_ID, U.COST_CTR_TYP AS COST_CTR_TYP, U.SERVICE_CD AS SERVICE_CD, U.DURATION AS DURATION, U.OSN AS OSN, \r\n")
			.append("U.STOP_LIST AS STOP_LIST, U.NUM_STOP AS NUM_STOP, U.LAST_CTY AS LAST_CTY, U.STOP_ZONE AS STOP_ZONE, \r\n")
			.append("U.DISPATCH_DATETIME AS DISPATCH_DATETIME, U.STATUS AS STATUS \r\n")
			.append("FROM ( \r\n")
			.append("SELECT \r\n")
			.append(" (CASE WHEN a.trip_id IS NOT NULL AND FUN_GET_TRIP_PK(a.trip_id) LIKE 'D%' THEN FUN_GET_TRIP_PK(a.trip_id)\r\n")
		//--when ld.trip_id IS NOT NULL AND t.trip_dir != 'Outbound' AND t.PK1 like 'D%' THEN t.PK1 
		//--when (ld.trip_id IS NOT NULL AND t.trip_dir != 'Outbound' AND t.PK1 not like 'D%' AND ld.DMCL_CD IS NOT NULL AND length(dmcl_t.shpgloc_cd) <= 4) THEN dmcl_t.shpgloc_cd
			.append(" WHEN (a.trip_id IS NOT NULL AND a.FRST_SHPG_LOC_CD not like 'D%' AND a.DMCL_CD IS NOT NULL AND length(dmcl_t.shpgloc_cd) <= 4) THEN dmcl_t.shpgloc_cd\r\n")
			.append(" WHEN a.trip_id IS NULL AND a.FRST_SHPG_LOC_CD like 'D%' THEN a.FRST_SHPG_LOC_CD\r\n")
			.append(" WHEN (a.trip_id IS NULL AND a.FRST_SHPG_LOC_CD not like 'D%' AND a.DMCL_CD IS NOT NULL AND length(dmcl_t.shpgloc_cd) <= 4) THEN dmcl_t.shpgloc_cd\r\n")
			.append(" WHEN (a.trip_id IS NULL AND a.FRST_SHPG_LOC_CD not like 'D%' AND a.DMCL_CD IS NULL AND length(dom_carrier.shpgloc_cd) <= 4) THEN dom_carrier.shpgloc_cd\r\n")
			.append(" ELSE a.FRST_SHPG_LOC_CD end) AS Dispatch_DC,\r\n")
			.append(" FUN_GET_INT_DC(a.ld_leg_id) AS INT_DC,\r\n")
			.append(" decode(a.Trip_ID, NULL, nvl(to_char(A.STRD_DTT, 'yyyymmddhh24mi'), '00000000000000') \r\n")
			.append(" || a.LD_LEG_ID, nvl(to_char(FUN_GET_TRIP_STRD_DTT(a.trip_id), 'yyyymmddhh24mi'), '00000000000000')\r\n")
			.append(" || a.Trip_ID || a.SEQ_NUM) as MV_ID,\r\n")
			.append(" A.TRIP_ID, A.SEQ_NUM, A.LD_LEG_ID AS LOAD_ID, A.STRD_DTT AS START_DATE, A.CARR_CD AS CARRIER_ID,\r\n")
			//.append(" substr(domval('CARR_T','COST_CTR_TYP',C.COST_CTR_TYP),1,70) AS COST_CTR_TYP,\r\n")
			.append(" '' AS COST_CTR_TYP,\r\n")
			.append(" A.SRVC_CD AS SERVICE_CD, A.ELPD_HRS AS DURATION, substr(A.RFRC_NUM9, 1, 10)||' '||substr(A.RFRC_NUM9, 12, 5) AS OSN,\r\n")
			.append(" A.TRLR_NUM, A.TRCTR_NUM, A.DRVR, FUN_GET_STOP_LOC(A.LD_LEG_ID, 0) AS STOP_LIST,\r\n")
			.append(" A.NUM_STOP, FUN_GET_STOP_ZONE(A.LD_LEG_ID, A.NUM_STOP) AS STOP_ZONE, A.LAST_CTY_NAME AS LAST_CTY,\r\n")
			.append(" decode(a.trip_id, null, B.RPTD_DTT, FUN_GET_TRIP_DISPTCH_DTT(a.trip_id)) AS DISPATCH_DATETIME,\r\n")
			.append(" (CASE WHEN (B.RPTD_DTT IS NOT NULL AND B.RPTD_DTT <= A.STRD_DTT) THEN 'On-Time_Dispatched'\r\n")
			.append(" WHEN (B.RPTD_DTT IS NOT NULL AND B.RPTD_DTT > A.STRD_DTT) THEN 'Late_Dispatched'\r\n")
			.append(" WHEN (B.RPTD_DTT IS NULL AND A.STRD_DTT >= SYSDATE AND A.RFRC_NUM9 IS NOT NULL\r\n")
			.append(" AND A.TRLR_NUM IS NOT NULL) THEN 'Ready_For_Dispatch' \r\n")
			.append(" WHEN (B.RPTD_DTT IS NULL AND A.STRD_DTT < SYSDATE) THEN 'Late_For_Dispatch'\r\n")
			.append(" ELSE NULL\r\n")
			.append(" END) AS STATUS\r\n")
			
			.append(" FROM LD_LEG_T A, OP_AP_STATNST_T B, CARR_T C, SHPG_LOC_T LOC, DMCL_T, DMCL_T DOM_CARRIER\r\n")
			.append(" WHERE 1=1 AND A.CARR_CD = C.CARR_CD\r\n")
			.append(" AND A.FRST_SHPG_LOC_CD = LOC.SHPG_LOC_CD\r\n")
			.append(" AND A.FRST_SHPGPNT_ENU=LOC.SHPG_LOC_TYP_ENU\r\n")
			.append(" AND A.LD_LEG_ID = B.LD_LEG_ID(+)\r\n")
			.append(" AND A.DMCL_CD=DMCL_T.DMCL_CD(+)\r\n")
			.append(" AND DOM_CARRIER.CARR_CD(+)=A.CARR_CD\r\n")
			.append(" AND B.SEC_CD(+) = 'DEPART'\r\n");
			
			// check for START DATE
			if(null != dispatchSearchReq.getStartDate()) {
				searchString.append(" AND decode(a.trip_id, null, TRUNC(A.STRD_DTT), TRUNC(FUN_GET_TRIP_STRD_DTT(a.trip_id))) ")
					.append(" >= TRUNC(to_date('").append(dispatchSearchReq.getStartDate()).append("', 'yyyy-mm-dd'))\r\n");  //FROM DATE
			}
			
			//check for END DATE
			if (null != dispatchSearchReq.getEndDate()) {
				searchString.append(" AND decode(a.trip_id, null, TRUNC(A.STRD_DTT), TRUNC(FUN_GET_TRIP_STRD_DTT(a.trip_id))) ")
					.append(" <= TRUNC(to_date('").append(dispatchSearchReq.getEndDate()).append("', 'yyyy-mm-dd'))\r\n");  //TO DATE
			}

		//If "Tendered" is selected only load/trip after tendered status shown on Summary view. Otherwise load/trip after "Planned" status shown on Summary view
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getStatus()) && ObjectCheckUtil.isArrayContains(dispatchSearchReq.getStatus(), AppConstants.TENDERED) ) {
				searchString.append(" AND A.CUR_OPTLSTAT_ID >= 310\r\n"); //TENDERED
			} else {
				searchString.append(" AND A.CUR_OPTLSTAT_ID >= 305\r\n"); //PLANNED
			}
			searchString.append(" AND CUR_OPTLSTAT_ID != 355\r\n"); //CANCELLED

		//If "IB Deadhead" is selected, only show load/trip pick from vendor
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getStatus()) && ObjectCheckUtil.isArrayContains(dispatchSearchReq.getStatus(), AppConstants.IB_DEADHEAD) ) {
				searchString.append(" AND UPPER(SUBSTR(LOC.EXTL_CD2, 1, 6)) = 'VENDOR'\r\n");
			}

		//If "Billing Routes" is selected, only show load/trip with last location code having "BILL"
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getStatus()) && ObjectCheckUtil.isArrayContains(dispatchSearchReq.getStatus(), AppConstants.BILLING_ROUTES) ) {
				searchString.append(" AND UPPER(A.LAST_SHPG_LOC_CD) LIKE '%BILLING%' \r\n");
			}
		//If Route filter is used for search
			if ( null != dispatchSearchReq.getRoute() && dispatchSearchReq.getRoute().length() > 0 ) {
				searchString.append(" AND A.LD_LEG_ID LIKE '").append(dispatchSearchReq.getRoute()).append("'\r\n"); // replace 'p_load_id' with the passed parameter for route
			}

		//If Carrier ID filter is used for search
			if ( null != dispatchSearchReq.getCarrierId() && dispatchSearchReq.getCarrierId().length() > 0 ) {
				searchString.append(" AND A.CARR_CD = '").append(dispatchSearchReq.getCarrierId()).append("'\r\n"); // replace 'p_carr_cd' with the passed parameter for carrier id
			}
//			LOGGER.info("1 ---- ");

		//If Location ID filter is used for search
			if ( null != dispatchSearchReq.getLocationId() && dispatchSearchReq.getLocationId().length() > 0 ) {
				searchString.append(" AND A.LAST_SHPG_LOC_CD = '").append(dispatchSearchReq.getLocationId()).append("'\r\n"); // replace 'p_load_id' with the passed parameter for location id
			}

			searchString.append(" ) U WHERE 1=1\r\n");
				//.append(" AND DECODE(U.INT_DC, NULL, U.DISPATCH_DC, U.INT_DC) = '").append(dispatchSearchReq.getOwningLocations()[0]).append("'\r\n"); //TODO: check for the owning location value

		//If "Not Dispatched" is selected, only show load/trip without dispatch date (because trip put filter here)
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getStatus()) && ObjectCheckUtil.isArrayContains(dispatchSearchReq.getStatus(), AppConstants.NOT_DISPATCHED) ) {
				searchString.append(" AND U.RPTD_DTT IS NULL\r\n");
			}
//			LOGGER.info("2 ---- ");

		//If "Dispatched" is selected, only show load/trip with dispatch date populated
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getStatus()) && ObjectCheckUtil.isArrayContains(dispatchSearchReq.getStatus(), AppConstants.DISPATCHED) ) {
				searchString.append(" AND U.RPTD_DTT IS NOT NULL\r\n");
			}

		//If Alt Location is used for search, only show load/trip go through INT location
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getAltLocations()) ) {
				searchString.append(" AND U.INT_DC = '").append(dispatchSearchReq.getAltLocations()[0]).append("'\r\n");  // replace p_alt_loc value by passed parameter like '0003002972'  
			}
		//If Zone filter is used for search
			if ( !ObjectCheckUtil.isArrayEmpty(dispatchSearchReq.getZone()) ) {
				searchString.append(" U.STOP_ZONE = '").append(dispatchSearchReq.getZone()[0]).append("'\r\n");
			}

			searchString.append(" ORDER BY U.MV_ID\r\n");

			LOGGER.info("END -- DispatchSearchQuery ");
			return searchString.toString();
	}
	
}
