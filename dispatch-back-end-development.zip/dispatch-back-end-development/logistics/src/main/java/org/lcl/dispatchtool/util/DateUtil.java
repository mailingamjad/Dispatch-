package org.lcl.dispatchtool.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateUtil {

	public static Date stringToDate(String dateStr, String dateFormat) {
//		String string = "January 2, 2010";
		DateFormat format = new SimpleDateFormat(dateFormat, Locale.ENGLISH);
		Date date = null;
		try {
			date = format.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return date;
	}

	public static Date utcDateStringToDate(String dateStr){
		DateFormat jsfmt = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss");
		Date date = null;
		try {
//			System.out.println("Login Date: "+dateStr);
			date = jsfmt.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return date;
	}

	public static String getTimestamp(Date objDateP) {
		if (objDateP == null)
			return "''";

		return new StringBuffer("'").append(formatDate(objDateP, "MM/dd/yyyy HH:mm:ss")).append("'").toString();
	}

	/**
	 * Formats a date value into a specifed format.
	 *
	 * @param date
	 *            date value
	 * @param pattern
	 *            date format pattern
	 * @return formatted date
	 */
	public static String formatDate(final Date date, final String pattern) {
		if (date == null) {
			return "";
		}

		final SimpleDateFormat formatter = new SimpleDateFormat(pattern);
		formatter.setLenient(false);

		return formatter.format(date);
	}


	public static void main(String as []) {
		System.out.println("Date format from js : "+utcDateStringToDate("Fri, 07 Oct 2016 13:55:08 GMT"));
	}
}
