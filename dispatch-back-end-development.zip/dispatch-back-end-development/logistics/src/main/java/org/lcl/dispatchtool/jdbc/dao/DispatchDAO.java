package org.lcl.dispatchtool.jdbc.dao;

import java.util.List;

import org.lcl.dispatchtool.request.DispatchSearchRequest;
import org.lcl.dispatchtool.response.ListData;
import org.lcl.dispatchtool.response.SummaryData;

public interface DispatchDAO {

	public List<ListData> getOwningLocations(String[] extl_cd2);

	public List<ListData> getAltLocations(String[] extl_cd2);

	public List<ListData> getDispatchStatuses(String ln);

	public List<String> getDispatchRoutes(String query);

	public List<ListData> getDispatchCarrierIds(String query);

	public List<String> getDispatchLocationIds(String query);

	public List<String> getDispatchZones(String query);
	
	public List<SummaryData> getSearchData(DispatchSearchRequest dispatchSearchRequest);
}
