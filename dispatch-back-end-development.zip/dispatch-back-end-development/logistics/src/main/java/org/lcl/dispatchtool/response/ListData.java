package org.lcl.dispatchtool.response;

/*
 * @author Gaurang Patel
 * @
 */
public class ListData {

//	@JsonProperty(value = "key")
	private String key;

//	@JsonProperty(value = "value")
	private String value;

	public ListData() {
		// Do Nothing. Default Constructor.
	}

	public ListData(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
