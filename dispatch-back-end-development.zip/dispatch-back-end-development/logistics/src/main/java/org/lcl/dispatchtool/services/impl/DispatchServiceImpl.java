package org.lcl.dispatchtool.services.impl;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lcl.dispatchtool.jdbc.dao.DispatchDAO;
import org.lcl.dispatchtool.request.DispatchSearchRequest;
import org.lcl.dispatchtool.response.ListData;
import org.lcl.dispatchtool.response.SummaryData;
import org.lcl.dispatchtool.services.DispatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DispatchServiceImpl implements DispatchService {

    private static final Logger LOGGER = LogManager.getLogger(DispatchServiceImpl.class);

    @Autowired
	public DispatchDAO dispatchDAO;

	@Override
	public List<ListData> getOwningLocations(String[] extl_cd2) {
		List<ListData> owningLocationsList = dispatchDAO.getOwningLocations(extl_cd2);
		return owningLocationsList;
	}

	@Override
	public List<ListData> getAltLocations(String[] extl_cd2) {
		List<ListData> altLocationsList = dispatchDAO.getAltLocations(extl_cd2);
		return altLocationsList;
	}

	@Override
	public List<ListData> getDispatchStatuses(String ln) {
		List<ListData> dispatchStatusesList = dispatchDAO.getDispatchStatuses(ln);
		return dispatchStatusesList;
	}

	@Override
	public List<String> getDispatchRoutes(String query) {
		return dispatchDAO.getDispatchRoutes(query);
	}

	@Override
	public List<ListData> getDispatchCarrierIds(String query) {
		List<ListData> dispatchCarrierIdsList = dispatchDAO.getDispatchCarrierIds(query);
		return dispatchCarrierIdsList;
	}

	@Override
	public List<String> getDispatchLocationIds(String query) {
		return dispatchDAO.getDispatchLocationIds(query);
	}

	@Override
	public List<String> getDispatchZones(String query) {
		return dispatchDAO.getDispatchZones(query);
	}

	@Override
	public List<SummaryData> getSearchData(DispatchSearchRequest dispatchSearchReq) {
		LOGGER.info("START -- DispatchServiceImpl -- getSearchData -- ",dispatchSearchReq);
		return dispatchDAO.getSearchData(dispatchSearchReq);
	}
}
