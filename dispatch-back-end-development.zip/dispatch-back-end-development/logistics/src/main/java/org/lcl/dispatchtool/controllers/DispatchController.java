package org.lcl.dispatchtool.controllers;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lcl.dispatchtool.request.DispatchSearchRequest;
import org.lcl.dispatchtool.response.ListData;
import org.lcl.dispatchtool.response.SummaryData;
import org.lcl.dispatchtool.services.DispatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/dispatch")
@Api(value = "Dispatch Tool for LCL", description = "Dispatch Screen API")
public class DispatchController {

    private static final Logger LOGGER = LogManager.getLogger(DispatchController.class);

    @Autowired
	public DispatchService dispatchService;
	
    @RequestMapping(value = "/owninglocation", method = RequestMethod.GET)
	@ApiOperation(value="Dispatch Owning Locations API")
    public List<ListData> getOwningLocations(@RequestParam(value = "query", required = false) List<String> query) {
    	String[] queryP = query.toArray(new String[0]);
    	return dispatchService.getOwningLocations(queryP);
    }

    @RequestMapping(value = "/altlocation", method = RequestMethod.GET)
    public List<ListData> getAltLocations() {
    	return dispatchService.getAltLocations(null);
    }

    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public List<ListData> getStatus() {
    	return dispatchService.getDispatchStatuses(null);
    }

    @RequestMapping(value = "/locationIds", method = RequestMethod.GET)
    public List<String> getLocationIds(@RequestParam(value = "query", required = false) String query) {
    	return dispatchService.getDispatchLocationIds(query);
    }

    @RequestMapping(value = "/zone", method = RequestMethod.GET)
    public List<String> getZones(@RequestParam(value = "query", required = false) String query) {
    	return dispatchService.getDispatchZones(query);
    }

    @RequestMapping(value = "/carrierIds", method = RequestMethod.GET)
    public List<ListData> getCarrierIds(@RequestParam(value = "query", required = false) String query) {
    	return dispatchService.getDispatchCarrierIds(query);
    }

    @RequestMapping(value = "/route", method = RequestMethod.GET)
    public List<String> getRoutes(@RequestParam(value = "query", required = false) String query) {
    	return dispatchService.getDispatchRoutes(query);
    }

    @RequestMapping(value = "/search", method = RequestMethod.POST)
    public List<SummaryData> getSearchData(@RequestBody DispatchSearchRequest dispatchSearchReq) {
    	LOGGER.info("START -- DispatchController -- getSearchData -- "+dispatchSearchReq.toString());
    	return dispatchService.getSearchData(dispatchSearchReq);
//    	return null;
    }
}
