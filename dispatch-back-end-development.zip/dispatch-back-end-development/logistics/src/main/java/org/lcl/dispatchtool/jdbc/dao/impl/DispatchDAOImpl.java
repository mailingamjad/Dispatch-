package org.lcl.dispatchtool.jdbc.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import org.lcl.dispatchtool.jdbc.dao.DispatchDAO;
import org.lcl.dispatchtool.jdbc.query.DispatchDataQueryBuilder;
import org.lcl.dispatchtool.request.DispatchSearchRequest;
import org.lcl.dispatchtool.response.ListData;
import org.lcl.dispatchtool.response.SummaryData;

@Component
public class DispatchDAOImpl implements DispatchDAO {

    private static final Logger LOGGER = LogManager.getLogger(DispatchDAOImpl.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public List<ListData> getOwningLocations(String[] extl_cd2) {
		String owningLocationsQuery = DispatchDataQueryBuilder.getOwningLocations(extl_cd2);
		List<ListData> owningLocationsList = new ArrayList<ListData>();
		Object[] objects = null;
		List<Map<String, Object>> owningLocations = this.jdbcTemplate.queryForList(owningLocationsQuery, objects);
		ListData listData = null;
		for (Map<String, Object> mapData : owningLocations) {
			listData = new ListData();
			listData.setKey(mapData.get("SHPG_LOC_CD").toString());
			listData.setValue(mapData.get("NAME").toString());
			owningLocationsList.add(listData);
		}
		return owningLocationsList;
	}

	@Override
	public List<ListData> getAltLocations(String[] extl_cd2) {
		String altLocationsQuery = DispatchDataQueryBuilder.getAltLocations(extl_cd2);
		List<ListData> altLocationsList = new ArrayList<ListData>();
		Object[] objects = null;
		List<Map<String, Object>> altLocations = this.jdbcTemplate.queryForList(altLocationsQuery, objects);
		ListData listData = null;
		for (Map<String, Object> mapData : altLocations) {
			listData = new ListData();
			listData.setKey(mapData.get("SHPG_LOC_CD").toString());
			listData.setValue(mapData.get("NAME").toString());
			altLocationsList.add(listData);
		}
		return altLocationsList;
	}
	
	@Override
	public List<ListData> getDispatchStatuses(String ln) {
		String dispatchStatusesQuery = DispatchDataQueryBuilder.getDispatchStatuses(ln);
		List<ListData> dispatchStatusesList = new ArrayList<ListData>();
		Object[] objects = null;
		List<Map<String, Object>> dispatchStatuses = this.jdbcTemplate.queryForList(dispatchStatusesQuery, objects);
		ListData listData = null;
		for (Map<String, Object> mapData : dispatchStatuses) {
			listData = new ListData();
			listData.setKey(mapData.get("CODE").toString());
			listData.setValue(mapData.get("DESCRIPTION").toString());
			dispatchStatusesList.add(listData);
		}
		return dispatchStatusesList;
	}

	@Override
	public List<String> getDispatchRoutes(String query) {
		LOGGER.info("START -- DispatchDAOImpl -- getDispatchRoutes");
		String routesQuery = DispatchDataQueryBuilder.getDispatchRoutes(query);
		Object[] objects = null;
		if (StringUtils.hasLength(query)) {
			objects = new Object[] {"%"+query.toUpperCase()+"%"};
			LOGGER.info("Route Query Object >>>> "+objects[0].toString());
		}
		LOGGER.info("Route Query String >>>> "+routesQuery);
		List<String> routes = this.jdbcTemplate.query(routesQuery, objects, new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				String route = rs.getString("LD_LEG_ID");
				return route;
			}
		});
		return routes;
	}

	@Override
	public List<ListData> getDispatchCarrierIds(String query) {
		String carrierIdsQuery = DispatchDataQueryBuilder.getDispatchCarrierIds(query);
		Object[] objects = null;
		if (StringUtils.hasLength(query)) {
			objects = new Object[] {"%"+query.toUpperCase()+"%"};
			LOGGER.info("CarrierIds Query Object >>>> "+objects[0].toString());
		}
		List<ListData> dispatchCarrierIdsList = new ArrayList<ListData>();
		List<Map<String, Object>> dispatchCarrierIds = this.jdbcTemplate.queryForList(carrierIdsQuery, objects);
		ListData listData = null;
		for (Map<String, Object> mapData : dispatchCarrierIds) {
			listData = new ListData();
			listData.setKey(mapData.get("CARR_CD").toString());
			listData.setValue(mapData.get("CARR_NAME").toString());
			dispatchCarrierIdsList.add(listData);
		}
		return dispatchCarrierIdsList;
	}

	@Override
	public List<String> getDispatchLocationIds(String query) {
		String locationIdsQuery = DispatchDataQueryBuilder.getDispatchLocationIds(query);
		Object[] objects = null;
		if (StringUtils.hasLength(query)) {
			objects = new Object[] {"%"+query.toUpperCase()+"%"};
			LOGGER.info("LocationIds Query Object >>>> "+objects[0].toString());
		}
		List<String> locationIds = this.jdbcTemplate.query(locationIdsQuery, objects, new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				String locationId = rs.getString("SHPG_LOC_CD");
				return locationId;
			}
		});
		return locationIds;
	}

	@Override
	public List<String> getDispatchZones(String query) {
		String zonesQuery = DispatchDataQueryBuilder.getDispatchZones(query);
		Object[] objects = null;
		if (StringUtils.hasLength(query)) {
			objects = new Object[] {"%"+query.toUpperCase()+"%"};
			LOGGER.info("Zones Query Object >>>> "+objects[0].toString());
		}
		List<String> zones = this.jdbcTemplate.query(zonesQuery, objects, new RowMapper<String>() {
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				String zone = rs.getString("CORP2_ID");
				return zone;
			}
		});
		return zones;
	}

	@Override
	public List<SummaryData> getSearchData(DispatchSearchRequest dispatchSearchReq) {
		LOGGER.info("START ---- DispatchDAOImpl -- getSearchData ");
		String searchQuery = DispatchDataQueryBuilder.getSearchDataQuery(dispatchSearchReq);
		Object[] objects = null;
		List<SummaryData> summaryList = this.jdbcTemplate.query(searchQuery, objects, new RowMapper<SummaryData>() {
			public SummaryData mapRow(ResultSet rs, int rowNum) throws SQLException {
				SummaryData summary = new SummaryData();
				summary.setTripId(rs.getString("MV_ID"));
				summary.setSeqNum(rs.getString("SEQ_NUM"));
				summary.setLoadId(rs.getString("LOAD_ID"));
				summary.setStartDate(rs.getDate("START_DATE").toString());
				summary.setCarrierId(rs.getString("CARRIER_ID"));
				summary.setCostCtrTypr(rs.getString("COST_CTR_TYP"));
				summary.setServiceCode(rs.getString("SERVICE_CD"));
				summary.setDuration(rs.getString("DURATION"));
				summary.setOsn(rs.getString("OSN"));
				summary.setStopList(rs.getString("STOP_LIST"));
				summary.setNumStop(rs.getString("NUM_STOP"));
				summary.setLastCity(rs.getString("LAST_CTY"));
				summary.setStopZone(rs.getString("STOP_ZONE"));
				summary.setDispatchDate(rs.getString("DISPATCH_DATETIME"));
				summary.setStatus(rs.getString("STATUS"));
				return summary;
			}
		});
		return summaryList;
	}

}
