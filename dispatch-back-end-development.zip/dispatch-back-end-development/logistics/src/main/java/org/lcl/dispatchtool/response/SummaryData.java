package org.lcl.dispatchtool.response;

public class SummaryData {

	public String tripId;
	public String seqNum;
	public String loadId;
	public String startDate;
	public String carrierId;
	public String costCtrTypr;
	public String serviceCode;
	public String duration;
	public String osn;
	public String stopList;
	public String numStop;
	public String lastCity;
	public String stopZone;
	public String dispatchDate;
	public String status;
	public String getTripId() {
		return tripId;
	}
	public void setTripId(String tripId) {
		this.tripId = tripId;
	}
	public String getSeqNum() {
		return seqNum;
	}
	public void setSeqNum(String seqNum) {
		this.seqNum = seqNum;
	}
	public String getLoadId() {
		return loadId;
	}
	public void setLoadId(String loadId) {
		this.loadId = loadId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getCarrierId() {
		return carrierId;
	}
	public void setCarrierId(String carrierId) {
		this.carrierId = carrierId;
	}
	public String getCostCtrTypr() {
		return costCtrTypr;
	}
	public void setCostCtrTypr(String costCtrTypr) {
		this.costCtrTypr = costCtrTypr;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getOsn() {
		return osn;
	}
	public void setOsn(String osn) {
		this.osn = osn;
	}
	public String getStopList() {
		return stopList;
	}
	public void setStopList(String stopList) {
		this.stopList = stopList;
	}
	public String getNumStop() {
		return numStop;
	}
	public void setNumStop(String numStop) {
		this.numStop = numStop;
	}
	public String getLastCity() {
		return lastCity;
	}
	public void setLastCity(String lastCity) {
		this.lastCity = lastCity;
	}
	public String getStopZone() {
		return stopZone;
	}
	public void setStopZone(String stopZone) {
		this.stopZone = stopZone;
	}
	public String getDispatchDate() {
		return dispatchDate;
	}
	public void setDispatchDate(String dispatchDate) {
		this.dispatchDate = dispatchDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
