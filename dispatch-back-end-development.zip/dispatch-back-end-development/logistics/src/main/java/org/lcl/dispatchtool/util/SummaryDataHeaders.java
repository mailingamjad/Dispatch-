package org.lcl.dispatchtool.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SummaryDataHeaders {

	private static final Map<String, List<String>> DISPATCH_SUMMARY = new HashMap<String, List<String>>();

	static {
		DISPATCH_SUMMARY.put("MAIN", getList("Name", "Type", "Phone", "Email"));// User Contacts
	}

	public static List<String> getList(String... header) {
		List<String> headerArray = new ArrayList<String>();
		Collections.addAll(headerArray, header);
		return headerArray;
	}
	
	public static List<String> getHeadersById(String view) {
		return DISPATCH_SUMMARY.get(view);
	}

}
