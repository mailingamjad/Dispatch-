package org.lcl.dispatchtool.util;

public class AppConstants {

	public static final int RESULT_DATA_LIMIT = 30;
	
	// Dispatch Statuses
	public static final String TENDERED = "TENDED";
	public static final String NOT_DISPATCHED = "PDN";	
	public static final String DISPATCHED = "DPTED";	
	public static final String IB_DEADHEAD = "IBDEADHD";	
	public static final String BILLING_ROUTES = "BLRTE";
}
