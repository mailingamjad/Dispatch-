package org.lcl.dispatchtool.util;

public class ObjectCheckUtil {

	public static boolean isArrayContains(String[] arr, String targetValue) {
		for(String s: arr){
			if(s.equals(targetValue))
				return true;
		}
		return false;
	}
	
	public static boolean isArrayEmpty(String[] arr) {
		return (null == arr || arr.length == 0);
	}
}
